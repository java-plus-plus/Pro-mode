/**
 * @file main.c
 * @author your name (<Sem>/<Section>)
 * @version 0.1
 * @date 2022-02-22
 *
 * SCORE: xxx
 */
#include <stdio.h> // printf() and scanf() functions are defined inside stdio.h

int main()
{
    // Define all the required variables
    int num;

    printf("Enter any number: "); // Ask for the user input to multiply by i -> 10
    scanf("%d", &num);            // Take the user input

    for (int i = 1; i <= 10; i++)
    {
        /*
            Execute below code 10 times,
            initially value of i will be 1,
            and in each iteration the value of i will incremented by 1
        */
        printf("%d x %d = %d \n", i, num, i * num); // Print the value of i * num
    }
}