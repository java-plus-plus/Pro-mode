/**
 * @file MultiplicationTable.java
 * @author your name (<Sem>/<Section>)
 * @version 0.1
 * @date 2022-02-22
 *
 * SCORE: xxx
 */
import java.util.Scanner; // The Scanner class is defined here

class MultiplicationTable {
    public static void main(String[] args) {
        // Define all the required variables
        int num;

        Scanner scanner = new Scanner(System.in); // Create Scanner instance for taking user input

        System.out.println("Enter any number: "); // Ask for the user input to multiply by i -> 10
        num = scanner.nextInt();// Take the user input
        scanner.close(); // Since you got the required user input, you no longer need scanner, so close
        // it.

        for (int i = 1; i <= 10; i++) {
            /*
             * Execute below code 10 times,
             * initially value of i will be 1,
             * and in each iteration the value of i will incremented by 1
             */
            System.out.println(num + " x " + i + " = " + num * i); // Print the value of i * num
        }
    }
}
