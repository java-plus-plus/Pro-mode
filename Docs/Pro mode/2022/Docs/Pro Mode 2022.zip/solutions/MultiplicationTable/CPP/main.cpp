/**
 * @file main.cpp
 * @author your name (<Sem>/<Section>)
 * @version 0.1
 * @date 2022-02-22
 *
 * SCORE: xxx
 */
#include <iostream>  // cin and cout are defined inside iostream
using namespace std; // If you don't use this, you'll have to write "std::cout" all the time instead of simply "cout"

int main()
{
    // Define all the required variables
    int num;

    cout << "Enter any number: "; // Ask for the user input to multiply by i -> 10
    cin >> num;                   // Take the user input

    for (int i = 1; i <= 10; i++)
    {
        /*
            Execute below code 10 times,
            initially value of i will be 1,
            and in each iteration the value of i will incremented by 1
        */
        cout << i << " x " << num << " = " << i * num << endl; // Print the value of i * num
    }
}
